package id.co.xl.task.subscribertransaction;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SubscriberTransactionApplication {

	public static void main(String[] args) {
		SpringApplication.run(SubscriberTransactionApplication.class, args);
	}

}
