package id.co.xl.task.subscribertransaction.config.variable;

public class AppConstant {

}
