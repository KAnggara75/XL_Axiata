package id.co.xl.task.subscribertransaction;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SubscriberTransactionApplicationTests {

	@Test
	void contextLoads() {
	}

}
